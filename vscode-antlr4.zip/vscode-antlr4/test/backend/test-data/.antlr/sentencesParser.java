// Generated from c:\Repos\Sample\vscode-antlr4\test\backend\test-data\sentences.g4 by ANTLR 4.9.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class sentencesParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		DIGITS=1, UnicodeNumber=2, RED=3, GREEN=4, BLUE=5, OPEN_BRACE=6, CLOSE_BRACE=7, 
		COMMA=8, DOT=9, COLON=10, SimpleIdentifier=11, UnicodeIdentifier=12, WS=13;
	public static final int
		RULE_unicodeIdentifier = 0, RULE_plusLoop = 1, RULE_starLoop = 2, RULE_alts = 3, 
		RULE_blocks = 4, RULE_block = 5, RULE_alt1 = 6, RULE_alt2 = 7, RULE_alt3 = 8, 
		RULE_recursion = 9;
	private static String[] makeRuleNames() {
		return new String[] {
			"unicodeIdentifier", "plusLoop", "starLoop", "alts", "blocks", "block", 
			"alt1", "alt2", "alt3", "recursion"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, "'red'", "'green'", "'blue'", "'{'", "'}'", "','", 
			"'.'", "':'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "DIGITS", "UnicodeNumber", "RED", "GREEN", "BLUE", "OPEN_BRACE", 
			"CLOSE_BRACE", "COMMA", "DOT", "COLON", "SimpleIdentifier", "UnicodeIdentifier", 
			"WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "sentences.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public sentencesParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class UnicodeIdentifierContext extends ParserRuleContext {
		public TerminalNode UnicodeIdentifier() { return getToken(sentencesParser.UnicodeIdentifier, 0); }
		public UnicodeIdentifierContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unicodeIdentifier; }
	}

	public final UnicodeIdentifierContext unicodeIdentifier() throws RecognitionException {
		UnicodeIdentifierContext _localctx = new UnicodeIdentifierContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_unicodeIdentifier);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(20);
			match(UnicodeIdentifier);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PlusLoopContext extends ParserRuleContext {
		public List<TerminalNode> DIGITS() { return getTokens(sentencesParser.DIGITS); }
		public TerminalNode DIGITS(int i) {
			return getToken(sentencesParser.DIGITS, i);
		}
		public List<TerminalNode> COMMA() { return getTokens(sentencesParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(sentencesParser.COMMA, i);
		}
		public PlusLoopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_plusLoop; }
	}

	public final PlusLoopContext plusLoop() throws RecognitionException {
		PlusLoopContext _localctx = new PlusLoopContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_plusLoop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(22);
			match(DIGITS);
			setState(25); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(23);
				match(COMMA);
				setState(24);
				match(DIGITS);
				}
				}
				setState(27); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==COMMA );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StarLoopContext extends ParserRuleContext {
		public List<TerminalNode> DIGITS() { return getTokens(sentencesParser.DIGITS); }
		public TerminalNode DIGITS(int i) {
			return getToken(sentencesParser.DIGITS, i);
		}
		public StarLoopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_starLoop; }
	}

	public final StarLoopContext starLoop() throws RecognitionException {
		StarLoopContext _localctx = new StarLoopContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_starLoop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(29);
			match(DIGITS);
			setState(33);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DIGITS) {
				{
				{
				setState(30);
				match(DIGITS);
				}
				}
				setState(35);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AltsContext extends ParserRuleContext {
		public Alt1Context alt1() {
			return getRuleContext(Alt1Context.class,0);
		}
		public Alt2Context alt2() {
			return getRuleContext(Alt2Context.class,0);
		}
		public Alt3Context alt3() {
			return getRuleContext(Alt3Context.class,0);
		}
		public AltsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alts; }
	}

	public final AltsContext alts() throws RecognitionException {
		AltsContext _localctx = new AltsContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_alts);
		try {
			setState(40);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(36);
				alt1();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(37);
				alt2();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(38);
				alt3();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlocksContext extends ParserRuleContext {
		public List<BlockContext> block() {
			return getRuleContexts(BlockContext.class);
		}
		public BlockContext block(int i) {
			return getRuleContext(BlockContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(sentencesParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(sentencesParser.COMMA, i);
		}
		public BlocksContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blocks; }
	}

	public final BlocksContext blocks() throws RecognitionException {
		BlocksContext _localctx = new BlocksContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_blocks);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(42);
			block();
			setState(47);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(43);
				match(COMMA);
				setState(44);
				block();
				}
				}
				setState(49);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public TerminalNode OPEN_BRACE() { return getToken(sentencesParser.OPEN_BRACE, 0); }
		public TerminalNode CLOSE_BRACE() { return getToken(sentencesParser.CLOSE_BRACE, 0); }
		public List<TerminalNode> SimpleIdentifier() { return getTokens(sentencesParser.SimpleIdentifier); }
		public TerminalNode SimpleIdentifier(int i) {
			return getToken(sentencesParser.SimpleIdentifier, i);
		}
		public TerminalNode UnicodeIdentifier() { return getToken(sentencesParser.UnicodeIdentifier, 0); }
		public TerminalNode DIGITS() { return getToken(sentencesParser.DIGITS, 0); }
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(50);
			match(OPEN_BRACE);
			setState(57);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SimpleIdentifier:
				{
				setState(51);
				match(SimpleIdentifier);
				setState(53);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==SimpleIdentifier) {
					{
					setState(52);
					match(SimpleIdentifier);
					}
				}

				}
				break;
			case UnicodeIdentifier:
				{
				setState(55);
				match(UnicodeIdentifier);
				setState(56);
				match(DIGITS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(59);
			match(CLOSE_BRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Alt1Context extends ParserRuleContext {
		public TerminalNode RED() { return getToken(sentencesParser.RED, 0); }
		public Alt1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alt1; }
	}

	public final Alt1Context alt1() throws RecognitionException {
		Alt1Context _localctx = new Alt1Context(_ctx, getState());
		enterRule(_localctx, 12, RULE_alt1);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(61);
			match(RED);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Alt2Context extends ParserRuleContext {
		public TerminalNode GREEN() { return getToken(sentencesParser.GREEN, 0); }
		public Alt2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alt2; }
	}

	public final Alt2Context alt2() throws RecognitionException {
		Alt2Context _localctx = new Alt2Context(_ctx, getState());
		enterRule(_localctx, 14, RULE_alt2);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(63);
			match(GREEN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Alt3Context extends ParserRuleContext {
		public TerminalNode BLUE() { return getToken(sentencesParser.BLUE, 0); }
		public Alt3Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alt3; }
	}

	public final Alt3Context alt3() throws RecognitionException {
		Alt3Context _localctx = new Alt3Context(_ctx, getState());
		enterRule(_localctx, 16, RULE_alt3);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(65);
			match(BLUE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RecursionContext extends ParserRuleContext {
		public TerminalNode DIGITS() { return getToken(sentencesParser.DIGITS, 0); }
		public RecursionContext recursion() {
			return getRuleContext(RecursionContext.class,0);
		}
		public TerminalNode SimpleIdentifier() { return getToken(sentencesParser.SimpleIdentifier, 0); }
		public TerminalNode DOT() { return getToken(sentencesParser.DOT, 0); }
		public AltsContext alts() {
			return getRuleContext(AltsContext.class,0);
		}
		public TerminalNode COLON() { return getToken(sentencesParser.COLON, 0); }
		public RecursionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_recursion; }
	}

	public final RecursionContext recursion() throws RecognitionException {
		return recursion(0);
	}

	private RecursionContext recursion(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		RecursionContext _localctx = new RecursionContext(_ctx, _parentState);
		RecursionContext _prevctx = _localctx;
		int _startState = 18;
		enterRecursionRule(_localctx, 18, RULE_recursion, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(71);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DIGITS:
				{
				setState(68);
				match(DIGITS);
				setState(69);
				recursion(2);
				}
				break;
			case SimpleIdentifier:
				{
				setState(70);
				match(SimpleIdentifier);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(81);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(79);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
					case 1:
						{
						_localctx = new RecursionContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_recursion);
						setState(73);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(74);
						match(DOT);
						setState(75);
						alts();
						}
						break;
					case 2:
						{
						_localctx = new RecursionContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_recursion);
						setState(76);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(77);
						match(COLON);
						setState(78);
						alts();
						}
						break;
					}
					} 
				}
				setState(83);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 9:
			return recursion_sempred((RecursionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean recursion_sempred(RecursionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 4);
		case 1:
			return precpred(_ctx, 3);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\17W\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\3"+
		"\2\3\2\3\3\3\3\3\3\6\3\34\n\3\r\3\16\3\35\3\4\3\4\7\4\"\n\4\f\4\16\4%"+
		"\13\4\3\5\3\5\3\5\3\5\5\5+\n\5\3\6\3\6\3\6\7\6\60\n\6\f\6\16\6\63\13\6"+
		"\3\7\3\7\3\7\5\78\n\7\3\7\3\7\5\7<\n\7\3\7\3\7\3\b\3\b\3\t\3\t\3\n\3\n"+
		"\3\13\3\13\3\13\3\13\5\13J\n\13\3\13\3\13\3\13\3\13\3\13\3\13\7\13R\n"+
		"\13\f\13\16\13U\13\13\3\13\2\3\24\f\2\4\6\b\n\f\16\20\22\24\2\2\2W\2\26"+
		"\3\2\2\2\4\30\3\2\2\2\6\37\3\2\2\2\b*\3\2\2\2\n,\3\2\2\2\f\64\3\2\2\2"+
		"\16?\3\2\2\2\20A\3\2\2\2\22C\3\2\2\2\24I\3\2\2\2\26\27\7\16\2\2\27\3\3"+
		"\2\2\2\30\33\7\3\2\2\31\32\7\n\2\2\32\34\7\3\2\2\33\31\3\2\2\2\34\35\3"+
		"\2\2\2\35\33\3\2\2\2\35\36\3\2\2\2\36\5\3\2\2\2\37#\7\3\2\2 \"\7\3\2\2"+
		"! \3\2\2\2\"%\3\2\2\2#!\3\2\2\2#$\3\2\2\2$\7\3\2\2\2%#\3\2\2\2&+\5\16"+
		"\b\2\'+\5\20\t\2(+\5\22\n\2)+\3\2\2\2*&\3\2\2\2*\'\3\2\2\2*(\3\2\2\2*"+
		")\3\2\2\2+\t\3\2\2\2,\61\5\f\7\2-.\7\n\2\2.\60\5\f\7\2/-\3\2\2\2\60\63"+
		"\3\2\2\2\61/\3\2\2\2\61\62\3\2\2\2\62\13\3\2\2\2\63\61\3\2\2\2\64;\7\b"+
		"\2\2\65\67\7\r\2\2\668\7\r\2\2\67\66\3\2\2\2\678\3\2\2\28<\3\2\2\29:\7"+
		"\16\2\2:<\7\3\2\2;\65\3\2\2\2;9\3\2\2\2<=\3\2\2\2=>\7\t\2\2>\r\3\2\2\2"+
		"?@\7\5\2\2@\17\3\2\2\2AB\7\6\2\2B\21\3\2\2\2CD\7\7\2\2D\23\3\2\2\2EF\b"+
		"\13\1\2FG\7\3\2\2GJ\5\24\13\4HJ\7\r\2\2IE\3\2\2\2IH\3\2\2\2JS\3\2\2\2"+
		"KL\f\6\2\2LM\7\13\2\2MR\5\b\5\2NO\f\5\2\2OP\7\f\2\2PR\5\b\5\2QK\3\2\2"+
		"\2QN\3\2\2\2RU\3\2\2\2SQ\3\2\2\2ST\3\2\2\2T\25\3\2\2\2US\3\2\2\2\13\35"+
		"#*\61\67;IQS";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}