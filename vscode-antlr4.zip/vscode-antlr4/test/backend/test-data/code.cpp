#include <iostream.h>

main()
{
    cout << "Hello World!";
    return 0;
}
