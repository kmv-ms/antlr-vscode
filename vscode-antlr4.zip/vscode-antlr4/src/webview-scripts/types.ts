/*
 * Copyright (c) Mike Lischke. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */

// Types for use in webview modules.

import { ATNStateType, TransitionType } from "antlr4ts/atn";
import { SimulationLinkDatum, SimulationNodeDatum } from "d3";
import { Uri } from "vscode";

export interface IWebviewMessage {
    [key: string]: unknown;
}

/** Describes the structure of the object returned by `acquireVsCodeApi()`. */
export interface IVSCode {
    postMessage(message: IWebviewMessage): void;
    getState(): unknown;
    setState(state: unknown): void;
}

/**
 * A range within a text. Just like the range object in vscode the end position is not included in the range.
 * Hence when start and end position are equal the range is empty.
 */

export interface ILexicalRange {
    start: { column: number; row: number; };
    end: { column: number; row: number; };
}

/** The definition of a single symbol (range and content it is made of). */
export interface IDefinition {
    text: string;
    range: ILexicalRange;
}

/**
 * Contains a number of values for a lexer token. Used when constructing a token list and parse trees in the debugger.
 */
export interface ILexerToken {
    [key: string]: string | number | object;

    text: string;
    type: number;
    name: string;
    line: number;
    offset: number; // Offset in the line.
    channel: number;
    tokenIndex: number;
    startIndex: number;
    stopIndex: number;
}

/**
 * Describes the a range in an input stream (character indexes in a char stream or token indexes in a token stream).
 * Indexes can be < 0 if there's no input representation for a tree node (e.g. when it did not match anything).
 */
export interface IIndexRange {
    startIndex: number;
    stopIndex: number;
    length: number;
}

/**
 * This interface is a duplicate of the same named interface in backend/types.ts. We need the duplication
 * because it's used both, in the (CommonJS) extension code and the (ESM) webview code.
 */
export interface IParseTreeNode {
    type: "rule" | "terminal" | "error";
    id: number; // A unique id for D3.js.

    ruleIndex?: number; // Only valid for the rule node type.
    name: string;
    start?: ILexerToken; // ditto
    stop?: ILexerToken; // ditto
    range?: IIndexRange; // ditto

    symbol?: ILexerToken; // Only valid for non-rule nodes.

    children: IParseTreeNode[]; // Available for all node types, but empty for non-rule types.
}

export interface IATNGraphRendererData {
    uri: Uri;
    ruleName?: string;
    maxLabelCount: number;
    graphData?: IATNGraphData;
    initialScale: number;
    initialTranslation: { x?: number; y?: number; };
}

export interface IATNGraphUpdateMessageData {
    command: "updateATNTreeData";
    graphData: IATNGraphRendererData;
}

export interface IATNStateSaveMessage extends IWebviewMessage {
    command: "saveATNState";
    nodes: IATNGraphLayoutNode[];
    uri: Uri;
    rule: string;
    transform: d3.ZoomTransform;
}

export interface IATNNode {
    id: number; // A unique number (positive for state numbers, negative for rule nodes)
    name: string;

    // We use the INVALID_TYPE in this field to denote a rule node.
    type: ATNStateType;
}

export interface IATNLink {
    source: number;
    target: number;
    type: TransitionType;
    labels: Array<{ content: string; class?: string; }>;
}

/**
 * Contains the link + node values which describe the ATN graph for a single rule.
 */
export interface IATNGraphData {
    nodes: IATNNode[];
    links: IATNLink[];
}

export interface IATNGraphLayoutNode extends SimulationNodeDatum, IATNNode {
    width?: number;
    endX?: number;
    endY?: number;
}

export interface IATNGraphLayoutLink extends SimulationLinkDatum<IATNGraphLayoutNode> {
    type: TransitionType;
    labels: Array<{ content: string; class?: string; }>;
}

export interface ICallGraphEntry {
    name: string;
    references: string[];
}
